

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item has-treeview menu-open">
        
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(route('post.index')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Posts</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('category.index')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Categories</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('tag.index')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Tags</p>
                </a>
              </li>
            </li>
            <li class="nav-item">
              <a href="<?php echo e(route('blog')); ?>" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Users</p>
              </a>
            </li>
            </ul>
        </li>
             
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    <?php /**PATH C:\xampp\htdocs\blog\resources\views/admin/layouts/sidebar_menu.blade.php ENDPATH**/ ?>