<footer class="main-footer">
    <strong>Copyright &copy; <a href="http://adminlte.io">Admin.io</a>.</strong>
    All rights reserved.
    </div>

    <?php $__env->startSection('footerSection'); ?>

      <?php echo $__env->yieldSection(); ?>
</footer><?php /**PATH C:\xampp\htdocs\blog\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>