<!-- Sidebar user panel (optional) -->
<div class="user-panel mt-3 pb-3 mb-3 d-flex">
    <div class="image">
      <img src="<?php echo e(asset('admin/img/user2-160x160.jpg')); ?>" class="img-circle elevation-2" alt="User Image">
    </div>

    <?php if(session('message')): ?>
        <div class="info">
            <a href="#" class="d-block"><?php echo e(session('message')); ?></a>
        </div>
        <META HTTP-EQUIV="Refresh" CONTENT="1; URL=<?php echo e(route('admin.home')); ?>">
    <?php else: ?>
        <div class="alert alert-danger">Invalid User</div>
    <?php endif; ?>
    
    
</div><?php /**PATH C:\xampp\htdocs\blog\resources\views/admin/layouts/admin_name.blade.php ENDPATH**/ ?>