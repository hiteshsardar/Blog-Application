

    <?php $__env->startSection('bg-img', asset('user/img/post-bg.jpg')); ?>
    <?php $__env->startSection('heading', 'POST VIEW'); ?>
    <?php $__env->startSection('sub-heading', "Let's Learn together and Grow together"); ?>

    <?php $__env->startSection('main-content'); ?>
         <!-- Post Content -->
        <article>
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-md-10 mx-auto">
                        
                        <h2 class="section-heading"><?php echo e($posts['title']); ?></h2>

                        <p><?php echo e($posts['sub_title']); ?></p>

                        <blockquote class="blockquote"><?php echo e($posts['slug']); ?></blockquote>

                        <p><?php echo e($posts['body']); ?></p>
                        <a href="#">
                            <img class="img-fluid" src="<?php echo e(asset('img/'.$posts['image'])); ?>" alt="Image Source isn't found.">
                        </a>            

                    </div>
                </div><br>
                <form action="<?php echo e(route('user_comment', $posts['id'])); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <div class="card card-outline card-info">
                        <div class="card-header">
                            <h6 class="card-title">Write Comments</h6>
                        </div>
                        <!-- /.card-header -->
                        <?php echo $__env->make('errors.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <div class="card-body pad text-right">
                            <div class="mb-3">
                                <textarea class="textarea" placeholder="Your comments is Valuable for us" id="comment" name="comment" 
                                style="width: 100%; height: 50px; font-size: 14px; line-height: 8px; border: 1px solid #dddddd; padding: 10px;"></textarea>
                                <p id="post_comment"></p>
                            </div>
                        
                                <button type="submit" class="btn btn-primary" id="">Comment</button>
                            
                        </div>
                    </div>
                </form><br>
                <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p><?php echo e($comment -> user_name); ?><br>
                        <?php echo e($comment -> comments); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                
            </div>
        </article>

        <hr>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('user/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/user/post.blade.php ENDPATH**/ ?>