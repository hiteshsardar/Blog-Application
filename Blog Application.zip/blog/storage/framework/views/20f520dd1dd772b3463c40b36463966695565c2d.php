

<?php $__env->startSection('bg-img', asset('user/img/home-bg.jpg')); ?>
<?php $__env->startSection('heading', 'POST HEADING'); ?>
<?php $__env->startSection('sub-heading', "Let's Learn together and Grow together"); ?>

<?php $__env->startSection('main-content'); ?>
    <!-- Main Content -->
    <div class="container">
        <div class="row">
        <div class="col-lg-8 col-md-10 mx-auto">

            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="post-preview">
                <a href="<?php echo e(route('show', $post -> id)); ?>">
                    <h2 class="post-title">
                        <?php echo e($post -> title); ?>

                    </h2>
                    <h3 class="post-subtitle">
                        <?php echo e($post -> sub_title); ?>

                    </h3>
                </a>
                <p class="post-meta d-inline-block">Author : 
                    <a href="#"><?php echo e($post -> author_name); ?></a>
                    <p class="post-meta d-inline-block">
                        &nbsp; Last Updated at : <?php echo e($post -> updated_at); ?>

                    </p>
                </p>
                </div>
                <hr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($posts -> links()); ?>

        </div>
        </div>
    </div>
    <hr>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/user/blog.blade.php ENDPATH**/ ?>