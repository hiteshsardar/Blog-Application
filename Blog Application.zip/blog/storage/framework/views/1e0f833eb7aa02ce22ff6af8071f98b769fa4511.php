

<?php $__env->startSection('main-content'); ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
        <div class="col-sm-6">
            <h1>Posts Page</h1>
        </div>
        <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>">Home</a></li>
            <li class="breadcrumb-item active">Posts Page</li>
            </ol>
        </div>
        </div>
    </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

        <!-- Default box -->
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Posts</h3>&nbsp;&nbsp;
                <a class="col-lg-offset-5 btn btn-success" href="<?php echo e(route('post.create')); ?>">Add New Post</a>

                <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                    <i class="fas fa-minus"></i></button>
                    <button type="button" class="btn btn-tool" data-card-widget="remove" data-toggle="tooltip" title="Remove">
                    <i class="fas fa-times"></i></button>
                </div>
            </div>
            <div class="card-body">
                <div class="card">
                    <div class="row">
                        
                        <div class="col-md-6">
                            <h3 class="card-title">&nbsp;Post DataTable</h3>
                        </div>
                        <form action="/search" method="GET">
                            <div class="input-group">
                                <input type="search" name="search" id="search" class="form-control" placeholder="Search by title">
                                <span class="input-group-prepend">
                                    <button class="btn btn-primary" id="search_btn">Search</button>
                                </span>
                                
                                <div class="dropdown">
                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                    <button class="dropbtn" disabled> Sorting </button>
                                    <div class="dropdown-content">
                                        <a href="<?php echo e(route('assending_order')); ?>">Assendig</a>
                                        <a href="<?php echo e(route('descending_order')); ?>">Descending</a>
                                    </div>
                                </div>
                               
                            </div>
                        </form>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">

                        <?php if(session('success')): ?>
                            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                        <?php endif; ?>
                        
                        <table id="post_table" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Serial No</th>
                                    <th>Title</th>
                                    <th>Sub Title</th>
                                    <th>Slug</th>
                                    <th>Author_name</th>
                                    <th>Post_status</th>
                                    <th>Created At</th>
                                    <th>Edit</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop -> index + 1); ?></td>
                                        <td><?php echo e($post -> title); ?></td>
                                        <td><?php echo e($post -> sub_title); ?></td>
                                        <td><?php echo e($post -> slug); ?></td>
                                        <td><?php echo e($post -> author_name); ?></td>
                                        <td><?php echo e($post -> status); ?></td>
                                        <td><?php echo e($post -> created_at); ?></td>
                                        <td><a href="<?php echo e(route('post.edit', $post -> id)); ?>">Edit</span></a></td>
                                        <td><form id="delete-form-<?php echo e($post -> id); ?>" method="POST" 
                                            action="<?php echo e(route('post.destroy', $post -> id)); ?>" style="display: none">
                                            <?php echo e(csrf_field()); ?>

                                            <?php echo e(method_field('DELETE')); ?>

                                            </form>
                                            <a href="" onclick="
                                            if(confirm('Are you Sure, to Delete this Data?')){
                                                event.preventDefault();
                                                document.getElementById('delete-form-<?php echo e($post -> id); ?>').submit();
                                            } else {
                                                event.preventDefault();
                                            }">Delete</span></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </tbody>
                        </table>
                        
                    </div>
                    <!-- /.card-body -->

                </div>
                <!-- /.card-body -->
                <?php echo e($posts -> links()); ?>

            </div>

        </div>
        <!-- /.card -->

    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/admin/post/show.blade.php ENDPATH**/ ?>