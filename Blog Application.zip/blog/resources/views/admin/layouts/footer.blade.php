<footer class="main-footer">
    <strong>Copyright &copy; <a href="http://adminlte.io">Admin.io</a>.</strong>
    All rights reserved.
    </div>

    @section('footerSection')

      @show
</footer>